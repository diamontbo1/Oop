﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;

/* FISHORAMA24 | .NET 6.0 | C.Blythe */
namespace FishORama
{
    /// CLASS: Piranha - Represents a Piranha fish in the FishORama engine
    class Piranha : IDraw
    {
        // CLASS VARIABLES
        private string textureID;               // Holds the ID for the texture used by the Piranha
        private float xPosition;                // X position on the screen
        private float yPosition;                // Y position on the screen
        private int xDirection;                 // Horizontal direction of movement
        private int yDirection;                 // Vertical direction of movement
        private Screen screen;                  // Reference to the screen dimensions
        private ITokenManager tokenManager;     // Reference to the TokenManager for other tokens

        private int teamNumber;                 // Team number for direction control
        private int fishNumber;                 // Unique fish number identifier
        private float originalY;                // The original Y position for movement limits
        private bool movingUp = true;           // Flag for vertical movement direction

        /// CONSTRUCTOR: Initializes the Piranha with given parameters
        public Piranha(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, int pFishNumber, int pTeamNumber)
        {
            textureID = pTextureID;
            xPosition = pXpos;
            yPosition = pYpos;
            screen = pScreen;
            tokenManager = pTokenManager;

            fishNumber = pFishNumber;
            teamNumber = pTeamNumber;

            xDirection = (teamNumber == 1) ? 1 : -1; // Set horizontal direction based on team
            yDirection = 1;  // Initial vertical movement direction
            originalY = yPosition;  // Save original Y position for movement limits
        }

        /// METHOD: Update - Controls the vertical movement of the Piranha (up and down)
        public void Update()
        {
            float moveSpeed = 1f;  // Speed of movement
            float range = 50f;     // Maximum vertical movement range

            // Move the Piranha up or down
            yPosition += movingUp ? -moveSpeed : moveSpeed;

            // Reverse direction if the Piranha reaches the movement limits
            if (yPosition <= originalY - range || yPosition >= originalY + range)
                movingUp = !movingUp;
        }

        /// METHOD: Draw - Renders the Piranha to the screen
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            // Get the asset associated with the Piranha texture
            Asset currentAsset = pAssetManager.GetAssetByID(textureID);

            // Determine if the texture should be flipped horizontally
            SpriteEffects horizontalDirection = (xDirection < 0) ? SpriteEffects.FlipHorizontally : SpriteEffects.None;

            // Draw the Piranha sprite to the screen
            pSpriteBatch.Draw(
                currentAsset.Texture,                                             // Texture
                new Vector2(xPosition, yPosition * -1),                            // Position (flip Y)
                null,                                                             // No source rectangle
                Color.White,                                                      // No tint
                0f,                                                               // No rotation
                new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2),    // Origin centered
                new Vector2(1, 1),                                                // No scale
                horizontalDirection,                                              // Flip horizontally if needed
                1                                                                  // Layer depth
            );
        }
    }
}
