﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using FishORamaEngineLibrary;

/* FISHORAMA24 | .NET 6.0 | C.Blythe */

namespace FishORama
{
    /// CLASS: Simulation class - the main class users code in to set up a FishORama simulation
    /// All tokens to be displayed in the scene are added here
    public class Simulation : IUpdate, ILoadContent
    {
        // CLASS VARIABLES
        // Variables store the information for the class
        private IKernel kernel;                 // Holds a reference to the game engine kernel which calls the draw method for every token you add to it
        private Screen screen;                  // Holds a reference to the screeen dimensions (width, height)
        private ITokenManager tokenManager;     // Holds a reference to the TokenManager - for access to ChickenLeg variable
        private Random rand;

        /// PROPERTIES
        public ITokenManager TokenManager     
        {
            set { tokenManager = value; }
        }

        // *** ADD YOUR CLASS VARIABLES HERE ***
        // Variables to hold fish will be declared here
        private Piranha[] Piranhasteam1 = new Piranha[3];
        private Piranha[] Piranhasteam2 = new Piranha[3];

        /// CONSTRUCTOR 
        /// Use constructors to set up the state of a class
        public Simulation(IKernel pKernel)
        {
            kernel = pKernel;                
            screen = kernel.Screen;            
            rand = new Random();
        }

        /// METHOD: LoadContent - called once at start of program
        /// Create all token objects and 'insert' them into the FishORama engine
        public void LoadContent(IGetAsset pAssetManager)
        {
            // *** ADD YOUR NEW TOKEN CREATION CODE HERE ***
            for (int i = 0; i < Piranhasteam1.Length; i++)
            {
                int fishNumber = i + 1;
                float y = 0f + i * 150f;

                Piranha p1 = new Piranha("Piranha1", -300f, y, screen, tokenManager, fishNumber, 1);
                Piranhasteam1[i] = p1;
                kernel.InsertToken(p1);

                Piranha p2 = new Piranha("Piranha1", 300f, y, screen, tokenManager, fishNumber, 2);
                Piranhasteam2[i] = p2;
                kernel.InsertToken(p2);

            }
        }

        /// METHOD: Update - called 60 times a second by the FishORama engine when the program is running
        /// Add all tokens so Update is called on them regularly
        public void Update(GameTime gameTime)
        {
            // *** ADD YOUR UPDATE CODE HERE ***
            // Each fish object (sitting in a variable) must have Update() called on it here
            foreach (var p in Piranhasteam1)
                p.Update();

            foreach (var p in Piranhasteam2)
                p.Update();

            if (tokenManager.ChickenLeg == null && rand.NextDouble() < 0.05)
            {
                PlaceLeg();
            }
        }

        private void PlaceLeg()
        {
            if (tokenManager.ChickenLeg == null)
            {
                float centerX = screen.width / 2f;
                float centerY = screen.height / 2f;

                ChickenLeg leg = new ChickenLeg("ChickenLeg", centerX, centerY, screen, tokenManager);
                kernel.InsertToken(leg);
            }
        }


    }
}
