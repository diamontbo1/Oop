﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;

/* FISHORAMA24 | .NET 6.0 | C.Blythe */

namespace FishORama
{
    /// CLASS: Piranha - represents a single piranha fish object in the simulation
    /// Implements IDraw to allow the FishORama engine to draw it on screen
    class Piranha : IDraw
    {
        // === REQUIRED TOKEN FIELDS ===
        // These fields are needed for all tokens (objects displayed in FishORama)
        private string textureID;             // ID of the texture to be used when drawing this piranha
        private float xPosition;              // X-coordinate of the piranha's position
        private float yPosition;              // Y-coordinate of the piranha's position
        private int xDirection;               // Direction of movement on the X-axis (1 = right, -1 = left)
        private int yDirection;               // Direction of movement on the Y-axis (not actively used here)
        private Screen screen;                // Reference to the screen dimensions
        private ITokenManager tokenManager;   // Reference to the TokenManager (used for accessing ChickenLeg if needed)

        // *** ADD YOUR CLASS VARIABLES HERE *** 
        private int teamNumber;               // The team this piranha belongs to (1 or 2)
        private int fishNumber;              // Unique number for each fish in its team
        private float originalY;              // The original Y-position of the fish (used to oscillate up/down)
        private bool movingUp = true;         // State variable to track whether the fish is moving upward

        /// CONSTRUCTOR: Piranha Constructor
        /// The elements in the brackets are PARAMETERS, which will be covered later in the course
        public Piranha(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager, int pfishnumber, int pteamnumber)
        {
            textureID = pTextureID;
            xPosition = pXpos;
            yPosition = pYpos;
            screen = pScreen;
            tokenManager = pTokenManager;
            // *** ADD OTHER INITIALISATION (class setup) CODE HERE ***
            fishNumber = pfishnumber;
            teamNumber = pteamnumber;
            xDirection = (teamNumber == 1) ? 1 : -1;   // Team 1 looks right, Team 2 faces left
            yDirection = 1;
            originalY = yPosition;
        }

        /// === METHOD: Update ===
        /// Moves the fish up and down vertically in a smooth loop between two Y-limits
        public void Update()
        {
            // *** ADD YOUR MOVEMENT/BEHAVIOUR CODE HERE ***
            float speed = 1f;
            if (movingUp)
                yPosition -= speed;
            else
                yPosition += speed;

            if (yPosition <= originalY - 50f)
                movingUp = false;
            else if (yPosition >= originalY + 50f)
                movingUp = true;
        }


        /// === METHOD: Draw ===
        /// Required for rendering the token
        /// Uses the texture ID to get the correct image and draws it in the correct orientation
        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            Asset currentAsset = pAssetManager.GetAssetByID(textureID); // Get this token's asset from the AssetManager

            SpriteEffects horizontalDirection; // Stores whether the texture should be flipped horizontally

            if (xDirection < 0)
            {
                // If the token's horizontal direction is negative, draw it reversed
                horizontalDirection = SpriteEffects.FlipHorizontally;
            }
            else
            {
                // If the token's horizontal direction is positive, draw it regularly
                horizontalDirection = SpriteEffects.None;
            }

            // Draw an image centered at the token's position, using the associated texture / position
            pSpriteBatch.Draw(currentAsset.Texture,                                             // Texture
                              new Vector2(xPosition, yPosition * -1),                                // Position
                              null,                                                             // Source rectangle (null)
                              Color.White,                                                      // Background colour
                              0f,                                                               // Rotation (radians)
                              new Vector2(currentAsset.Size.X / 2, currentAsset.Size.Y / 2),    // Origin (places token position at centre of sprite)
                              new Vector2(1, 1),                                                // scale (resizes sprite)
                              horizontalDirection,                                              // Sprite effect (used to reverse image - see above)
                              1);                                                               // Layer depth
        }
    }
}
