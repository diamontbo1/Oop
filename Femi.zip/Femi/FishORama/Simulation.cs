﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using FishORamaEngineLibrary;

/* FISHORAMA24 | .NET 6.0 | C.Blythe */

namespace FishORama
{
    /// CLASS: Simulation class - the main class users code in to set up a FishORama simulation
    /// All tokens to be displayed in the scene are added here
    public class Simulation : IUpdate, ILoadContent
    {
        // CLASS VARIABLES
        // Variables store the information for the class
        private IKernel kernel;                 // Holds a reference to the game engine kernel which calls the draw method for every token you add to it
        private Screen screen;                  // Holds a reference to the screeen dimensions (width, height)
        private ITokenManager tokenManager;     // Holds a reference to the TokenManager - for access to ChickenLeg variable
        private Random rand;

        /// PROPERTIES
        public ITokenManager TokenManager      // Property to access chickenLeg variable
        {   
            set { tokenManager = value; }
        }

        // *** ADD YOUR CLASS VARIABLES HERE ***
        // Variables to hold fish will be declared here
        private Piranha[] T1Piranhas = new Piranha[3];
        private Piranha[] T2Piranhas = new Piranha[3];

        /// CONSTRUCTOR - for the Simulation class - run once only when an object of the Simulation class is INSTANTIATED (created)
        /// Use constructors to set up the state of a class
        public Simulation(IKernel pKernel)
        {
            kernel = pKernel;                   // Stores the game engine kernel which is passed to the constructor when this class is created
            screen = kernel.Screen;             // Sets the screen variable in Simulation so the screen dimensions are accessible

            // *** ADD OTHER INITIALISATION (class setup) CODE HERE ***
            rand = new Random();
        }

        /// METHOD: LoadContent - called once at start of program
        /// Create all token objects and 'insert' them into the FishORama engine
        public void LoadContent(IGetAsset pAssetManager)
        {
            // *** ADD YOUR NEW TOKEN CREATION CODE HERE ***
            // Code to create fish tokens and assign to thier variables goes here
            // Remember to insert each token into the kernel
            for (int i = 0; i < T1Piranhas.Length; i++)
            {
                int fishNumber = i + 1;
                float y = 0f + i * 150f;

                T1Piranhas[i] = new Piranha("Piranha1", -300f, y, screen, tokenManager, fishNumber, 1);
                kernel.InsertToken(T1Piranhas[i]);

                T2Piranhas[i] = new Piranha("Piranha1", 300f, y, screen, tokenManager, fishNumber, 2);
                kernel.InsertToken(T2Piranhas[i]);
            }
        }

        /// METHOD: Update - called 60 times a second by the FishORama engine when the program is running
        /// Add all tokens so Update is called on them regularly
        public void Update(GameTime gameTime)
        {
            // *** ADD YOUR UPDATE CODE HERE ***
            // Each fish object (sitting in a variable) must have Update() called on it here
            foreach (var p in T1Piranhas)
                p.Update();

            foreach (var p in T2Piranhas)
                p.Update();

            if (tokenManager.ChickenLeg == null && rand.NextDouble() < 0.05)
            {
                PlaceLeg();
            }
        }

        private void PlaceLeg()
        {
            if (tokenManager.ChickenLeg != null) return;

            var leg = new ChickenLeg("ChickenLeg", screen.width / 2f, screen.height / 2f, screen, tokenManager);
            kernel.InsertToken(leg);
        }

    }
}
