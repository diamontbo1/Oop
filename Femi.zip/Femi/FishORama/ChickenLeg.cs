﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using FishORamaEngineLibrary;

namespace FishORama
{
    class ChickenLeg : IDraw
    {
        private string textureID;
        private float xPosition;
        private float yPosition;
        private Screen screen;
        private ITokenManager tokenManager;

        public ChickenLeg(string pTextureID, float pXpos, float pYpos, Screen pScreen, ITokenManager pTokenManager)
        {
            textureID = pTextureID;
            xPosition = pXpos;
            yPosition = pYpos;
            screen = pScreen;
            tokenManager = pTokenManager;
        }

        public void Update()
        {
            // No movement because its static.
        }

        public void Draw(IGetAsset pAssetManager, SpriteBatch pSpriteBatch)
        {
            Asset asset = pAssetManager.GetAssetByID(textureID);

            pSpriteBatch.Draw(
                asset.Texture,
                new Vector2(xPosition, yPosition),
                null,
                Color.White,
                0f,
                new Vector2(asset.Size.X / 2, asset.Size.Y / 2),
                new Vector2(1, 1),
                SpriteEffects.None,
                1
            );
        }

        public Vector2 GetPosition()
        {
            return new Vector2(xPosition, yPosition);
        }
    }
}
