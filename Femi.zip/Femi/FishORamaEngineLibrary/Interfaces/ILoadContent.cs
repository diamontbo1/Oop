﻿namespace FishORamaEngineLibrary
{
    public interface ILoadContent
    {
        void LoadContent(IGetAsset pAssetManager);
    }
}
