﻿using Microsoft.Xna.Framework;

namespace FishORamaEngineLibrary
{
    interface IToken
    {
        Vector2 Position { get; }
    }
}
